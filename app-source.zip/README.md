# Contacts Dashboard (Android)

Manage phone + SIM contacts in one dashboard: stats, search, filters (Phone / SIM / Google / Favorites / Duplicates / No name),
call / SMS / WhatsApp, copy SIM -> phone and phone -> SIM, delete, clean duplicates, export VCF or CSV.

## Build the APK — Option A (no install, GitHub)
1. Create a new GitHub repository and upload all files from this folder.
2. Open the **Actions** tab -> "Build APK" runs automatically (~5 min).
3. Open the finished run -> download **ContactsDashboard-apk** -> unzip -> `app-debug.apk`.

## Build the APK — Option B (Android Studio)
Open this folder in Android Studio -> Build -> Build APK(s).

## Install
Copy `app-debug.apk` to your phone, open it, allow "Install unknown apps", then allow Contacts permission.
