package com.davidgo.contacts

import android.content.ContentProviderOperation
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.CommonDataKinds.StructuredName
import android.provider.ContactsContract.RawContacts

enum class Source(val label: String) { PHONE("Phone"), SIM("SIM"), GOOGLE("Google"), OTHER("Other") }

data class Contact(
    val key: String,
    val contactId: Long,          // -1 for SIM card (icc) entries
    val rawId: Long,              // -1 for SIM card (icc) entries
    val name: String,
    val numbers: List<String>,
    val source: Source,
    val account: String,
    val starred: Boolean,
    val fromIcc: Boolean = false,
)

fun normalize(number: String): String {
    val d = number.filter { it.isDigit() }
    return if (d.length > 9) d.takeLast(9) else d
}

class ContactRepository(private val ctx: Context) {
    private val cr get() = ctx.contentResolver
    private val iccUri: Uri = Uri.parse("content://icc/adn")

    // Messaging apps that copy contacts – hidden to avoid fake duplicates
    private val ignoredAccounts = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger", "com.viber.voip",
        "com.facebook.auth.login", "com.skype.contacts.sync", "org.thoughtcrime.securesms",
        "com.google.android.apps.tachyon", "com.imo.android.imoim",
    )

    private fun classify(type: String?): Source {
        val t = type?.lowercase() ?: return Source.PHONE
        return when {
            "sim" in t || "icc" in t || "usim" in t -> Source.SIM
            t == "com.google" -> Source.GOOGLE
            "phone" in t || "local" in t || "device" in t -> Source.PHONE
            else -> Source.OTHER
        }
    }

    fun loadAll(): List<Contact> {
        val accounts = HashMap<Long, Pair<String?, String?>>()
        cr.query(
            RawContacts.CONTENT_URI,
            arrayOf(RawContacts._ID, RawContacts.ACCOUNT_TYPE, RawContacts.ACCOUNT_NAME),
            "${RawContacts.DELETED}=0", null, null
        )?.use { c ->
            while (c.moveToNext()) accounts[c.getLong(0)] = c.getString(1) to c.getString(2)
        }

        data class Acc(var contactId: Long, var name: String, val nums: LinkedHashMap<String, String>, var starred: Boolean)
        val byRaw = LinkedHashMap<Long, Acc>()
        cr.query(
            Phone.CONTENT_URI,
            arrayOf(Phone.RAW_CONTACT_ID, Phone.CONTACT_ID, Phone.DISPLAY_NAME, Phone.NUMBER, ContactsContract.Contacts.STARRED),
            null, null, "${Phone.DISPLAY_NAME} COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val raw = c.getLong(0)
                val num = c.getString(3) ?: continue
                val acc = byRaw.getOrPut(raw) { Acc(c.getLong(1), c.getString(2) ?: "", LinkedHashMap(), c.getInt(4) == 1) }
                acc.nums.putIfAbsent(normalize(num), num.trim())
            }
        }

        val list = ArrayList<Contact>()
        for ((raw, a) in byRaw) {
            val (type, name) = accounts[raw] ?: (null to null)
            if (type != null && type in ignoredAccounts) continue
            list += Contact(
                key = "raw:$raw", contactId = a.contactId, rawId = raw, name = a.name,
                numbers = a.nums.values.toList(), source = classify(type),
                account = name ?: type ?: "Phone", starred = a.starred
            )
        }

        // If the phone does not expose SIM contacts as an account, read the SIM card directly
        if (list.none { it.source == Source.SIM }) list += loadIcc()
        return list.sortedBy { it.name.lowercase() }
    }

    private fun loadIcc(): List<Contact> {
        val out = ArrayList<Contact>()
        try {
            cr.query(iccUri, null, null, null, null)?.use { c ->
                val nameIdx = c.getColumnIndex("name")
                val numIdx = c.getColumnIndex("number")
                var i = 0
                while (c.moveToNext()) {
                    val num = if (numIdx >= 0) c.getString(numIdx) else null
                    if (num.isNullOrBlank()) continue
                    val name = if (nameIdx >= 0) c.getString(nameIdx) ?: "" else ""
                    out += Contact("icc:${i++}:$num", -1, -1, name, listOf(num), Source.SIM, "SIM card", false, fromIcc = true)
                }
            }
        } catch (_: Exception) { /* SIM not readable on this device */ }
        return out
    }

    fun addToPhone(name: String, number: String) {
        val ops = arrayListOf(
            ContentProviderOperation.newInsert(RawContacts.CONTENT_URI)
                .withValue(RawContacts.ACCOUNT_TYPE, null)
                .withValue(RawContacts.ACCOUNT_NAME, null).build(),
            ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE)
                .withValue(StructuredName.DISPLAY_NAME, name).build(),
            ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE)
                .withValue(Phone.NUMBER, number)
                .withValue(Phone.TYPE, Phone.TYPE_MOBILE).build(),
        )
        cr.applyBatch(ContactsContract.AUTHORITY, ops)
    }

    /** Returns true if the SIM accepted the contact. */
    fun addToSim(name: String, number: String): Boolean = try {
        val v = ContentValues().apply { put("tag", name.take(14)); put("number", number) }
        cr.insert(iccUri, v) != null
    } catch (_: Exception) { false }

    fun delete(c: Contact): Boolean = try {
        if (c.fromIcc) {
            val n = c.name.replace("'", "''"); val p = c.numbers.first().replace("'", "''")
            cr.delete(iccUri, "tag='$n' AND number='$p'", null) > 0
        } else {
            cr.delete(ContentUris.withAppendedId(RawContacts.CONTENT_URI, c.rawId), null, null) > 0
        }
    } catch (_: Exception) { false }

    fun setStarred(c: Contact, starred: Boolean) {
        if (c.contactId < 0) return
        val v = ContentValues().apply { put(ContactsContract.Contacts.STARRED, if (starred) 1 else 0) }
        cr.update(ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, c.contactId), v, null, null)
    }

    fun exportVcf(list: List<Contact>, uri: Uri) = write(uri, buildString {
        list.forEach { c ->
            append("BEGIN:VCARD\r\nVERSION:3.0\r\nFN:").append(c.name.ifBlank { c.numbers.first() }).append("\r\n")
            c.numbers.forEach { append("TEL;TYPE=CELL:").append(it).append("\r\n") }
            append("END:VCARD\r\n")
        }
    })

    fun exportCsv(list: List<Contact>, uri: Uri) = write(uri, buildString {
        append("Name,Phone,Source,Account\n")
        list.forEach { c ->
            c.numbers.forEach { n ->
                append(csv(c.name)).append(',').append(csv(n)).append(',')
                    .append(c.source.label).append(',').append(csv(c.account)).append('\n')
            }
        }
    })

    private fun csv(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

    private fun write(uri: Uri, text: String) {
        cr.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
    }
}
