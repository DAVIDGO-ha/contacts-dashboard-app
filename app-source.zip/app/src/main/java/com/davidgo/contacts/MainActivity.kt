@file:OptIn(ExperimentalMaterial3Api::class)

package com.davidgo.contacts

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel

private val Bg = Color(0xFF0F0B1E)
private val CardBg = Color(0xFF1C1633)
private val Purple = Color(0xFF8B5CF6)
private val Green = Color(0xFF22C55E)
private val Orange = Color(0xFFF59E0B)
private val Blue = Color(0xFF3B82F6)
private val Red = Color(0xFFEF4444)

private val AppColors = darkColorScheme(
    primary = Purple, background = Bg, surface = CardBg, surfaceVariant = CardBg,
    onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White,
    secondaryContainer = Purple.copy(alpha = .35f), onSecondaryContainer = Color.White,
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = AppColors) { Surface(color = Bg) { Root() } } }
    }
}

enum class Filter(val label: String) {
    ALL("All"), PHONE("Phone"), SIM("SIM"), GOOGLE("Google"), FAV("Favorites"), DUP("Duplicates"), NONAME("No name")
}

@Composable
fun Root(vm: ContactsViewModel = viewModel()) {
    val ctx = LocalContext.current
    fun granted() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
    var hasPerm by remember { mutableStateOf(granted()) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasPerm = granted(); if (hasPerm) vm.load()
    }
    LaunchedEffect(Unit) {
        if (hasPerm) vm.load()
        else permLauncher.launch(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS))
    }
    if (!hasPerm) {
        Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.Contacts, null, tint = Purple, modifier = Modifier.size(72.dp))
            Spacer(Modifier.height(16.dp))
            Text("Allow access to your contacts to see the dashboard.", color = Color.White)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { permLauncher.launch(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS)) }) { Text("Allow access") }
        }
    } else Dashboard(vm)
}

@Composable
fun Dashboard(vm: ContactsViewModel) {
    val ctx = LocalContext.current
    val all = vm.contacts
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf(Filter.ALL) }
    var selected by remember { mutableStateOf<Contact?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var showWeb by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }
    val snackbar = remember { SnackbarHostState() }
    fun ask(text: String, run: () -> Unit) { confirm = Pair(text, run) }

    val dupGroups = remember(all) {
        val map = LinkedHashMap<String, MutableList<Contact>>()
        all.forEach { c -> c.numbers.map(::normalize).filter { it.length >= 6 }.toSet().forEach { map.getOrPut(it) { mutableListOf() } += c } }
        map.values.filter { it.size > 1 }.map { g -> g.distinctBy { it.key } }.filter { it.size > 1 }.distinctBy { g -> g.map { it.key }.sorted() }
    }
    val dupKeys = remember(dupGroups) { dupGroups.flatten().map { it.key }.toSet() }

    val shown = remember(all, query, filter, dupKeys) {
        val q = query.trim().lowercase(); val qd = query.filter { it.isDigit() }
        all.filter { c ->
            when (filter) {
                Filter.ALL -> true
                Filter.PHONE -> c.source == Source.PHONE
                Filter.SIM -> c.source == Source.SIM
                Filter.GOOGLE -> c.source == Source.GOOGLE
                Filter.FAV -> c.starred
                Filter.DUP -> c.key in dupKeys
                Filter.NONAME -> c.name.isBlank()
            }
        }.filter { c ->
            q.isEmpty() || c.name.lowercase().contains(q) || (qd.isNotEmpty() && c.numbers.any { it.filter(Char::isDigit).contains(qd) })
        }.let { l -> if (filter == Filter.DUP) l.sortedBy { c -> normalize(c.numbers.first()) } else l }
    }

    var exportVcf by remember { mutableStateOf(true) }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        if (uri != null) vm.export(shown, uri, exportVcf)
    }

    LaunchedEffect(vm.message) { vm.message?.let { snackbar.showSnackbar(it); vm.message = null } }

    Scaffold(
        containerColor = Bg,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Contacts Dashboard", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg),
                actions = {
                    IconButton(onClick = { vm.syncToWebsite() }, enabled = !vm.syncing) { Icon(Icons.Filled.CloudUpload, "Sync to website") }
                    IconButton(onClick = { vm.load() }) { Icon(Icons.Filled.Refresh, "Refresh") }
                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Menu") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Website settings") }, leadingIcon = { Icon(Icons.Filled.Language, null) },
                            onClick = { menu = false; showWeb = true })
                        DropdownMenuItem(text = { Text("Export list as VCF") }, leadingIcon = { Icon(Icons.Filled.Download, null) },
                            onClick = { menu = false; exportVcf = true; exporter.launch("contacts.vcf") })
                        DropdownMenuItem(text = { Text("Export list as CSV (Excel)") }, leadingIcon = { Icon(Icons.Filled.TableChart, null) },
                            onClick = { menu = false; exportVcf = false; exporter.launch("contacts.csv") })
                        DropdownMenuItem(text = { Text("Copy all SIM contacts to phone") }, leadingIcon = { Icon(Icons.Filled.SimCard, null) },
                            onClick = { menu = false; ask("Copy every SIM contact that is not already on the phone?") { vm.copyAllSimToPhone() } })
                        DropdownMenuItem(text = { Text("Clean all duplicates") }, leadingIcon = { Icon(Icons.Filled.CleaningServices, null) },
                            onClick = { menu = false; ask("Delete the extra copies and keep one contact per number?") { vm.cleanDuplicates(dupGroups) } })
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }, containerColor = Purple) { Icon(Icons.Filled.PersonAdd, "Add", tint = Color.White) }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat("Total", all.size, Icons.Filled.People, Purple, Modifier.weight(1f)) { filter = Filter.ALL }
                    Stat("Phone", all.count { it.source == Source.PHONE }, Icons.Filled.PhoneAndroid, Green, Modifier.weight(1f)) { filter = Filter.PHONE }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat("SIM", all.count { it.source == Source.SIM }, Icons.Filled.SimCard, Orange, Modifier.weight(1f)) { filter = Filter.SIM }
                    Stat("Duplicates", dupKeys.size, Icons.Filled.ContentCopy, Red, Modifier.weight(1f)) { filter = Filter.DUP }
                }
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat("No name", all.count { it.name.isBlank() }, Icons.Filled.HelpOutline, Color(0xFFF59E0B), Modifier.weight(1f)) { filter = Filter.NONAME }
                    Stat("Favorites", all.count { it.starred }, Icons.Filled.Star, Color(0xFFFACC15), Modifier.weight(1f)) { filter = Filter.FAV }
                }
            }
            item {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search name or number") }, singleLine = true,
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "Clear") } },
                    shape = RoundedCornerShape(14.dp)
                )
            }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(Filter.entries.toList()) { f -> FilterChip(selected = filter == f, onClick = { filter = f }, label = { Text(f.label) }) }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${shown.size} contacts", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    if (vm.loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                }
            }
            items(shown, key = { it.key }) { c -> ContactRow(c, c.key in dupKeys) { selected = c } }
            if (!vm.loading && shown.isEmpty()) item {
                Text("No contacts here.", color = Color.Gray, modifier = Modifier.fillMaxWidth().padding(32.dp))
            }
        }
    }

    selected?.let { c ->
        ContactSheet(c, onDismiss = { selected = null },
            onAction = { a ->
                selected = null
                when (a) {
                    "call" -> ctx.open(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${c.numbers.first()}")))
                    "sms" -> ctx.open(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${c.numbers.first()}")))
                    "wa" -> ctx.open(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${c.numbers.first().filter(Char::isDigit)}")))
                    "copy" -> {
                        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                            .setPrimaryClip(ClipData.newPlainText("number", c.numbers.joinToString("\n")))
                        vm.message = "Number copied"
                    }
                    "edit" -> ctx.open(Intent(Intent.ACTION_EDIT, ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, c.contactId)))
                    "star" -> vm.toggleStar(c)
                    "toPhone" -> vm.copyToPhone(c)
                    "toSim" -> vm.copyToSim(c)
                    "delete" -> ask("Delete ${c.name.ifBlank { c.numbers.first() }}?") { vm.delete(c) }
                }
                Unit
            })
    }

    if (showWeb) WebDialog(vm.web.serverUrl, vm.web.apiKey, onDismiss = { showWeb = false }) { u, k ->
        vm.web.serverUrl = u; vm.web.apiKey = k; showWeb = false; vm.syncToWebsite()
    }

    if (showAdd) AddDialog(onDismiss = { showAdd = false }) { n, p, sim -> showAdd = false; vm.add(n, p, sim) }

    confirm?.let { (text, run) ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Are you sure?") }, text = { Text(text) },
            confirmButton = { TextButton(onClick = { confirm = null; run() }) { Text("Yes", color = Red) } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } },
            containerColor = CardBg
        )
    }
}

private fun Context.open(i: Intent) = try { startActivity(i) } catch (_: Exception) { }

@Composable
fun Stat(label: String, value: Int, icon: ImageVector, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = CardBg)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(color.copy(alpha = .18f)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text("$value", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(label, fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}

private fun sourceColor(s: Source) = when (s) { Source.PHONE -> Green; Source.SIM -> Orange; Source.GOOGLE -> Blue; Source.OTHER -> Color.Gray }

@Composable
fun ContactRow(c: Contact, isDup: Boolean, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = CardBg)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(sourceColor(c.source).copy(alpha = .25f)), contentAlignment = Alignment.Center) {
                Text(c.name.firstOrNull()?.uppercase() ?: "#", fontWeight = FontWeight.Bold, color = sourceColor(c.source))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(c.name.ifBlank { "(No name)" }, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = if (c.name.isBlank()) Color.Gray else Color.White, modifier = Modifier.weight(1f, fill = false))
                    if (c.starred) Icon(Icons.Filled.Star, null, tint = Color(0xFFFACC15), modifier = Modifier.padding(start = 4.dp).size(14.dp))
                }
                Text(c.numbers.joinToString("  ·  "), fontSize = 13.sp, color = Color.LightGray, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Column(horizontalAlignment = Alignment.End) {
                Tag(c.source.label, sourceColor(c.source))
                if (isDup) { Spacer(Modifier.height(4.dp)); Tag("Duplicate", Red) }
            }
        }
    }
}

@Composable
fun Tag(text: String, color: Color) {
    Text(text, fontSize = 11.sp, color = color, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(color.copy(alpha = .15f)).padding(horizontal = 8.dp, vertical = 2.dp))
}

@Composable
fun ContactSheet(c: Contact, onDismiss: () -> Unit, onAction: (String) -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = CardBg) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
            Text(c.name.ifBlank { "(No name)" }, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            c.numbers.forEach { Text(it, color = Color.LightGray) }
            Spacer(Modifier.height(4.dp))
            Tag("${c.source.label} · ${c.account}", sourceColor(c.source))
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                Action(Icons.Filled.Call, "Call", Green) { onAction("call") }
                Action(Icons.Filled.Sms, "SMS", Blue) { onAction("sms") }
                Action(Icons.Filled.Chat, "WhatsApp", Color(0xFF25D366)) { onAction("wa") }
                Action(Icons.Filled.ContentCopy, "Copy", Purple) { onAction("copy") }
            }
            Spacer(Modifier.height(12.dp))
            HorizontalDivider(color = Color.White.copy(alpha = .1f))
            if (!c.fromIcc) {
                SheetItem(Icons.Filled.Edit, "Edit contact") { onAction("edit") }
                SheetItem(if (c.starred) Icons.Filled.StarBorder else Icons.Filled.Star, if (c.starred) "Remove from favorites" else "Add to favorites") { onAction("star") }
            }
            if (c.source == Source.SIM) SheetItem(Icons.Filled.PhoneAndroid, "Copy to phone") { onAction("toPhone") }
            else SheetItem(Icons.Filled.SimCard, "Copy to SIM card") { onAction("toSim") }
            SheetItem(Icons.Filled.Delete, "Delete", Red) { onAction("delete") }
        }
    }
}

@Composable
fun Action(icon: ImageVector, label: String, color: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(8.dp)) {
        Box(Modifier.size(48.dp).clip(CircleShape).background(color.copy(alpha = .2f)), contentAlignment = Alignment.Center) { Icon(icon, label, tint = color) }
        Text(label, fontSize = 12.sp, color = Color.LightGray, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun SheetItem(icon: ImageVector, label: String, color: Color = Color.White, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = color); Spacer(Modifier.width(16.dp)); Text(label, color = color)
    }
}

@Composable
fun AddDialog(onDismiss: () -> Unit, onSave: (String, String, Boolean) -> Unit) {
    var name by remember { mutableStateOf("") }
    var number by remember { mutableStateOf("") }
    var toSim by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = CardBg,
        title = { Text("New contact") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                OutlinedTextField(number, { number = it }, label = { Text("Phone number") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !toSim, onClick = { toSim = false }, label = { Text("Save to phone") }, leadingIcon = { Icon(Icons.Filled.PhoneAndroid, null) })
                    FilterChip(selected = toSim, onClick = { toSim = true }, label = { Text("Save to SIM") }, leadingIcon = { Icon(Icons.Filled.SimCard, null) })
                }
            }
        },
        confirmButton = { TextButton(enabled = number.isNotBlank(), onClick = { onSave(name.trim(), number.trim(), toSim) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun WebDialog(url0: String, key0: String, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var url by remember { mutableStateOf(url0) }
    var key by remember { mutableStateOf(key0) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = CardBg,
        title = { Text("Website dashboard") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Your contacts are sent to your Clients Dashboard website.", color = Color.Gray, fontSize = 13.sp)
                OutlinedTextField(url, { url = it }, label = { Text("Website URL") }, placeholder = { Text("https://contacts.david-go.com") }, singleLine = true)
                OutlinedTextField(key, { key = it }, label = { Text("API key") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(enabled = url.isNotBlank() && key.isNotBlank(), onClick = { onSave(url, key) }) { Text("Save & sync") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
