package com.davidgo.contacts

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ContactsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ContactRepository(app)
    val web = WebSync(app)
    var syncing by mutableStateOf(false); private set

    var contacts by mutableStateOf<List<Contact>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var message by mutableStateOf<String?>(null)

    fun load() = viewModelScope.launch {
        loading = true
        contacts = try { withContext(Dispatchers.IO) { repo.loadAll() } } catch (e: Exception) {
            message = "Could not read contacts: ${e.message}"; emptyList()
        }
        loading = false
        if (web.configured && contacts.isNotEmpty()) syncToWebsite()
    }

    private fun act(done: String, reload: Boolean = true, block: suspend () -> Unit) = viewModelScope.launch {
        try { withContext(Dispatchers.IO) { block() }; message = done } catch (e: Exception) { message = "Error: ${e.message}" }
        if (reload) load()
    }

    fun add(name: String, number: String, toSim: Boolean) = act(if (toSim) "Saved to SIM" else "Saved to phone") {
        if (toSim) { if (!repo.addToSim(name, number)) error("This SIM does not allow writing") }
        else repo.addToPhone(name, number)
    }

    fun copyToPhone(c: Contact) = act("Copied to phone") { repo.addToPhone(c.name, c.numbers.first()) }

    fun copyToSim(c: Contact) = act("Copied to SIM") {
        if (!repo.addToSim(c.name, c.numbers.first())) error("This SIM does not allow writing")
    }

    fun copyAllSimToPhone() = act("SIM contacts copied to phone") {
        val phoneNums = contacts.filter { it.source != Source.SIM }.flatMap { it.numbers.map(::normalize) }.toSet()
        contacts.filter { it.source == Source.SIM }
            .filter { s -> s.numbers.none { normalize(it) in phoneNums } }
            .forEach { repo.addToPhone(it.name, it.numbers.first()) }
    }

    fun syncToWebsite() = viewModelScope.launch {
        if (!web.configured) { message = "Set the website URL and API key first"; return@launch }
        syncing = true
        message = try { "Synced: " + withContext(Dispatchers.IO) { web.sync(contacts) } } catch (e: Exception) { "Sync failed: ${e.message}" }
        syncing = false
    }

    fun delete(c: Contact) = act("Deleted") { if (!repo.delete(c)) error("Could not delete") }

    /** Keeps one contact per number (prefers Phone, then names) and deletes the rest. */
    fun cleanDuplicates(groups: List<List<Contact>>) = act("Duplicates cleaned") {
        val kept = HashSet<String>(); val deleted = HashSet<String>()
        groups.forEach { g ->
            val alive = g.filter { it.key !in deleted }
            if (alive.size < 2) return@forEach
            val keep = alive.firstOrNull { it.key in kept }
                ?: alive.sortedWith(compareBy<Contact>({ it.source != Source.PHONE }, { it.name.isBlank() })).first()
            kept += keep.key
            alive.filter { it.key != keep.key && it.key !in kept }.forEach { repo.delete(it); deleted += it.key }
        }
    }

    fun toggleStar(c: Contact) = act(if (c.starred) "Removed from favorites" else "Added to favorites") {
        repo.setStarred(c, !c.starred)
    }

    fun export(list: List<Contact>, uri: Uri, vcf: Boolean) = act("Exported ${list.size} contacts", reload = false) {
        if (vcf) repo.exportVcf(list, uri) else repo.exportCsv(list, uri)
    }
}
