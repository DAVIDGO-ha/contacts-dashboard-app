package com.davidgo.contacts

import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** Registers this phone as a client on the Clients Dashboard website and uploads its contacts. */
class WebSync(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("web", Context.MODE_PRIVATE)

    var serverUrl: String
        get() = prefs.getString("url", "https://contacts.david-go.com") ?: "https://contacts.david-go.com"
        set(v) = prefs.edit().putString("url", v.trim().trimEnd('/')).apply()
    var apiKey: String
        get() = prefs.getString("key", "") ?: ""
        set(v) = prefs.edit().putString("key", v.trim()).apply()

    /** A stable ID for this installation, created once and reused for every sync. */
    val deviceId: String
        get() = prefs.getString("deviceId", null) ?: UUID.randomUUID().toString()
            .also { prefs.edit().putString("deviceId", it).apply() }

    val configured get() = serverUrl.isNotBlank()

    fun sync(list: List<Contact>): String {
        val arr = JSONArray()
        list.forEach { c ->
            arr.put(JSONObject().apply {
                put("name", c.name)
                put("numbers", JSONArray(c.numbers))
                put("source", c.source.label)
            })
        }
        val body = JSONObject().apply {
            put("deviceId", deviceId)
            put("deviceName", "${Build.MANUFACTURER} ${Build.MODEL}")
            put("appVersion", "1.0")
            put("contacts", arr)
        }.toString()

        val conn = URL("$serverUrl/api/sync").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000; conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("X-API-Key", apiKey)
            conn.outputStream.use { it.write(body.toByteArray()) }
            val code = conn.responseCode
            if (code == 401) error("Wrong API key")
            if (code != 200) error("Server error $code")
            val r = JSONObject(conn.inputStream.bufferedReader().readText())
            return "you are client ${r.optString("clientNo")} · ${r.optInt("contactsStored")} contacts uploaded"
        } finally { conn.disconnect() }
    }
}
