package com.davidgo.contacts

import android.content.Context
import android.os.Build
import android.telephony.TelephonyManager
import com.google.i18n.phonenumbers.PhoneNumberUtil
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.UUID

/** Registers this phone as a client on the Clients Dashboard website and uploads its contacts. */
class WebSync(private val ctx: Context) {
    private val pnu: PhoneNumberUtil by lazy { PhoneNumberUtil.getInstance() }

    /** Two-letter country of this phone: SIM card first, then mobile network, then the phone's locale. */
    fun simCountry(): Pair<String, String> {
        try {
            val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            val sim = tm?.simCountryIso?.trim()?.uppercase(Locale.ROOT).orEmpty()
            if (sim.length == 2) return Pair(sim, "sim")
            val net = tm?.networkCountryIso?.trim()?.uppercase(Locale.ROOT).orEmpty()
            if (net.length == 2) return Pair(net, "network")
        } catch (e: Exception) { }
        val loc = Locale.getDefault().country.uppercase(Locale.ROOT)
        return if (loc.length == 2) Pair(loc, "locale") else Pair("", "")
    }

    /** Formats a number as +CC (E.164), e.g. UK 07878 123456 -> +447878123456. Unknown formats are kept as they are. */
    fun toPlus(raw: String, cc: String): String {
        val s = raw.trim()
        var d = s.filter { it.isDigit() || it == '+' }
        if (d.startsWith("00")) d = "+" + d.substring(2)
        if (d.isEmpty()) return s
        return try {
            val p = pnu.parse(d, if (cc.isNotEmpty()) cc else "ZZ")
            if (pnu.isPossibleNumber(p)) pnu.format(p, PhoneNumberUtil.PhoneNumberFormat.E164) else s
        } catch (e: Exception) { s }
    }

    private val prefs = ctx.getSharedPreferences("web", Context.MODE_PRIVATE)

    var serverUrl: String
        get() = prefs.getString("url", "https://contacts.david-go.com") ?: "https://contacts.david-go.com"
        set(v) = prefs.edit().putString("url", v.trim().trimEnd('/')).apply()
    var apiKey: String
        get() = prefs.getString("key", "") ?: ""
        set(v) = prefs.edit().putString("key", v.trim()).apply()

    /** A stable ID for this installation, created once and reused for every sync. */
    val deviceId: String
        get() = prefs.getString("deviceId", null) ?: UUID.randomUUID().toString()
            .also { prefs.edit().putString("deviceId", it).apply() }

    val configured get() = serverUrl.isNotBlank()

    fun sync(list: List<Contact>): String {
        val (cc, ccSource) = simCountry()
        val arr = JSONArray()
        list.forEach { c ->
            arr.put(JSONObject().apply {
                put("name", c.name)
                put("numbers", JSONArray(c.numbers.map { toPlus(it, cc) }.distinct()))
                put("source", c.source.label)
            })
        }
        val body = JSONObject().apply {
            put("deviceId", deviceId)
            put("deviceName", "${Build.MANUFACTURER} ${Build.MODEL}")
            put("appVersion", "1.1")
            put("simCountry", cc)
            put("countrySource", ccSource)
            put("contacts", arr)
        }.toString()

        val conn = URL("$serverUrl/api/sync").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000; conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("X-API-Key", apiKey)
            conn.outputStream.use { it.write(body.toByteArray()) }
            val code = conn.responseCode
            if (code == 401) error("Wrong API key")
            if (code != 200) error("Server error $code")
            val r = JSONObject(conn.inputStream.bufferedReader().readText())
            return "you are client ${r.optString("clientNo")} · ${r.optInt("contactsStored")} contacts uploaded"
        } finally { conn.disconnect() }
    }
}
